	'is_force'=>'强制',
	'is_default'=>'默认',
