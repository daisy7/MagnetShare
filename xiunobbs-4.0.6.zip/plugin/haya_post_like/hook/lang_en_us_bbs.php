<?php
exit;

'haya_post_like' => 'Post Like ',

'haya_post_like_reply' => 'reply',

'haya_post_like_notice' => 'Thumbed up',

'haya_post_like_setting_open_thread' => 'Thumb up thread',
'haya_post_like_setting_open_thread_tip' => 'Open thumb up setting.',
'haya_post_like_setting_list_show_likes' => 'Show thumb-up in thread list',
'haya_post_like_setting_list_show_likes_tip' => 'Can thread-list show thumb-up ? Start, it is close.',

'haya_post_like_setting_thread_like_position' => 'Thumb up thread',
'haya_post_like_setting_thread_like_position_tip' => 'Setting thumb\'s option when you thumb up',
'haya_post_like_setting_thread_like_position_update_before' => 'update before',
'haya_post_like_setting_thread_like_position_message_after' => 'thread message after',

'haya_post_like_setting_open_post' => 'Thumb up post',
'haya_post_like_setting_open_post_tip' => 'Open thumb up post setting.',
'haya_post_like_setting_post_like_position' => 'Thumb up in where',
'haya_post_like_setting_post_like_position_tip' => 'Setting thumb\'s option when you thumb up',
'haya_post_like_setting_post_like_position_create_date_after' => 'create date after',
'haya_post_like_setting_post_like_position_quote_before' => 'quote before',
'haya_post_like_setting_post_like_position_filelist_after' => 'message after',
'haya_post_like_setting_post_like_position_filelist_after_right' => 'message after right',
'haya_post_like_setting_post_like_position_filelist_after_media' => 'message after media',

'haya_post_like_setting_post_like_loved_color' => 'post loved color',
'haya_post_like_setting_post_like_loved_color_tip' => 'setting post loved color',

'haya_post_like_setting_open_hot_like' => 'Open Hot Like',
'haya_post_like_setting_open_hot_like_tip' => 'open hot like list.',
'haya_post_like_setting_hot_like_post_low_count' => 'Hot post',
'haya_post_like_setting_hot_like_post_low_count_tip' => 'Hot-post what having count will be hot.',
'haya_post_like_setting_hot_like_post_size' => 'Hot-post size',
'haya_post_like_setting_hot_like_post_size_tip' => 'can show Hot-post count',
'haya_post_like_setting_hot_like_isfirst' => 'Hot-post need the thread',
'haya_post_like_setting_hot_like_isfirst_tip' => 'Hot-post need the thread ? Start, it is close.',
'haya_post_like_setting_hot_like_life_time' => 'Hot-post Life-time',
'haya_post_like_setting_hot_like_life_time_tip' => 'Setting Hot-post`s life-time.',

'haya_post_like_setting_clear_hot_like' => 'Clear Hot-like',
'haya_post_like_setting_now_clear_hot_like' => 'clear cache',
'haya_post_like_setting_no_clear_hot_like' => 'no clear cache',
'haya_post_like_setting_clear_hot_like_tip' => 'Clear Hot-like.',

'haya_post_like_setting_like_is_delete' => 'User can thumb down',
'haya_post_like_setting_like_is_delete_tip' => 'Can do user thumb down ? Start, it is open.',
'haya_post_like_setting_delete_time' => 'Thumb-down need time',
'haya_post_like_setting_delete_time_tip' => 'After user thumb up, can the user need some time do what he can do other and he do not thumb up ? ',
'haya_post_like_setting_open_my_post_like' => 'Open my post-like',
'haya_post_like_setting_open_my_post_like_tip' => 'Show my post-like in my center.',
'haya_post_like_setting_my_post_like_pagesize' => 'My post like pagesize',
'haya_post_like_setting_my_post_like_pagesize_tip' => 'Setting my Post-like pagesize in my center.',
'haya_post_like_setting_post_like_count_type' => 'Count Type',
'haya_post_like_setting_post_like_count_type_tip' => 'If you find what counting is error, start it.',
'haya_post_like_setting_success_tip' => 'Setting update success',

'haya_post_like_like' => 'thumb up',
'haya_post_like_unlike' => 'thumb down',
'haya_post_like_has_like' => 'thumbed up',
'haya_post_like_like_count' => 'thumbed-up count',
'haya_post_like_like_post' => 'thumbed-up post',
'haya_post_like_like_thread' => 'thumbed-up thread',
'haya_post_like_tip_title' => 'Thumbed up tip',
'haya_post_like_login_like_tip' => 'Thumbed up when you login !',
'haya_post_like_login_like_thread_tip' => 'Thumbed up the thread, you need login ! Click <b class="text-primary">confirm</b> to login.',
'haya_post_like_login_like_post_tip' => 'Thumbed up the post, you need login ! Click <b class="text-primary">confirm</b> to login.',

'haya_post_like_hot_post' => 'hot-post',

'haya_post_like_close_thread_tip' => 'Do not thumb up the thread!',
'haya_post_like_close_post_tip' => 'Do not thumb up the post!',
'haya_post_like_user_has_like_tip' => 'You have thumbed up!',
'haya_post_like_like_success_tip' => 'Thumb up success!',
'haya_post_like_unlike_success_tip' => 'Thumb down success!',
'haya_post_like_no_unlike_tip' => 'Do not thumb down!',
'haya_post_like_user_no_like_tip' => 'You are not haved thumbed up!',
'haya_post_like_no_fast_like_tip' => 'Do not thumb down fast!',
'haya_post_like_like_error_tip' => 'Watch For Error!',

'haya_post_like_my_no_post_like_tip' => 'You see error!',

'haya_post_like_send_notice_for_thread' => 'Thumbed up your thread {thread}',
'haya_post_like_send_notice_for_post' => 'Thumbed up your post {post} in thread {thread}',

?>