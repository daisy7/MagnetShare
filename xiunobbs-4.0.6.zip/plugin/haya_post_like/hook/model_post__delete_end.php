<?php
exit;

haya_post_like_delete_by_pid($pid);	

?>