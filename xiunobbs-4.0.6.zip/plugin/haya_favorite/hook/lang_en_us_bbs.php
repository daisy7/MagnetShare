<?php
exit;

'haya_favorite' => 'Thread Favorite ',

'haya_favorite_setting_user_favorite' => 'One Page Favorite Count',
'haya_favorite_setting_user_favorite_tip' => 'Show favorite count on one page',

'haya_favorite_setting_user_favorite_count' => 'User Favorite Count',
'haya_favorite_setting_user_favorite_count_tip' => 'Show users who has favorited.',

'haya_favorite_setting_thread_show_favorite' => 'Thread Show Favorite',
'haya_favorite_setting_thread_show_favorite_tip' => 'If do you show hot favorite in thread list ?',

'haya_favorite_setting_favorite_count_type' => 'Favorite Count Type',
'haya_favorite_setting_favorite_count_type_tip' => 'Favoriteing-count is error, you need open it.',

'haya_favorite_setting_show_hot_favorite' => 'Hot Favorite',
'haya_favorite_setting_show_hot_favorite_tip' => 'If show hot favorite in home sidebar ?',

'haya_favorite_setting_hot_favorite_count' => 'Hot Favorite Time',
'haya_favorite_setting_hot_favorite_count_tip' => 'Show hot favorite count who user favorite.',

'haya_favorite_setting_hot_favorite_find_time' => 'Hot Favorite Find Time',
'haya_favorite_setting_hot_favorite_find_time_tip' => 'Set hot-favorite last find-time，0 is find all，default is 30 days。',

'haya_favorite_setting_hot_favorite_cache_time' => 'Hot Favorite Clear-time',
'haya_favorite_setting_hot_favorite_cache_time_tip' => 'Set hot favorite clear time, 0 is no cache，default is 86400. ',

'haya_favorite_setting_clear_hot_favorite' => 'Clear hot favorite time',
'haya_favorite_setting_now_clear_hot_favorite' => 'clear',
'haya_favorite_setting_no_clear_hot_favorite' => 'no clear',
'haya_favorite_setting_clear_hot_favorite_tip' => 'Clear hot favorite time setting.',

'haya_favorite_setting_success' => 'Favorite setting success.',

'haya_favorite_name' => 'Favorite',
'haya_favorite_hot_favorite_name' => 'hot favorite',
'haya_favorite_no_hot_favorite' => 'no hot favorite ~',
'haya_favorite_count' => 'favorite count',

'haya_favorite_home' => 'home',
'haya_favorite_add' => 'Favorite',
'haya_favorite_add_favorite' => 'favorite thread',
'haya_favorite_delete' => 'Delete',
'haya_favorite_delete_favorite' => 'delete favorite',
'haya_favorite_remove_favorite' => 'remove favorite',
'haya_favorite_users' => 'Favorite Users',
'haya_favorite_show_favorite_users' => 'show favorite users',
'haya_favorite_login_favorite_tip' => 'favorite, you need login! Logining! ',
'haya_favorite_loading' => 'now loading~',
'haya_favorite_load_error_tip' => 'loading error~',
'haya_favorite_error' => 'error!',
'haya_favorite_add_favorite_confirm_title' => 'favorite tip',
'haya_favorite_add_favorite_confirm_content' => 'Do you want delete favorite the thread ?',
'haya_favorite_no_user_favorite' => 'no users favorite the thread~',
'haya_favorite_my_no_favorite' => 'no favorite~',
'haya_favorite_order' => 'order',
'haya_favorite_order_desc' => 'desc',
'haya_favorite_order_asc' => 'asc',

'haya_favorite_my_favorite' => 'my favorite',
'haya_favorite_user_favorite_error_tip' => 'favorite, you need login!',
'haya_favorite_user_have_favorite_tip' => 'you have favorited !',
'haya_favorite_user_favorite_success_tip' => 'favorited success !',
'haya_favorite_user_no_favorite_error_tip' => 'you no favorite !',
'haya_favorite_user_delete_favorite_success_tip' => 'favorite success !',

'haya_favorite_send_notice_for_thread' => 'favorited your thread <a target="_blank" href="{thread_url}" title="{thread_subject}">《{thread_substr_subject}》</a>.',

