<?php
exit;

155 => array(
	'url' => url('my-notice-155'), 
	'name' => lang('haya_favorite_name'),
	'class' => 'success',
	'icon' => ''
),

?>