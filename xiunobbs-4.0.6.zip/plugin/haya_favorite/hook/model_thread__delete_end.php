<?php
exit;

haya_favorite_delete_by_tid($tid);

?>