<?php
exit;

$haya_favorite_config = setting_get('haya_favorite');

?>